
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/**
 * 
 */
public class MySQLConnection {

    /**
     * 
     */
    public MySQLConnection() {
    }

    /**
     * 
     */
    public void Open() {
        // TODO implement here
        Console.WriteLine( "Opening an Oracle - based connection");
    }

}