
// NO BRAINER 01
#include <cstdio>
#include <string>
#include <iostream>

using namespace std;

int main()
{
	// std::string stands "type TEXT"

	string LunchMoney;
	cout << "Please enter amount in dollars" << endl;

	cin >> LunchMoney;
	cout << "you spent " << LunchMoney << endl; 
	return 0;
}
